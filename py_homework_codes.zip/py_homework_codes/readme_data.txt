Observatie:

Am atasat datele de intrare-iesire separat pentru fiecare implementare(folder-ul "data").Acestea exista si in folder-ul fiecarui algoritm in parte(nu sunt grupate intr-un subfolder intrucat am incercat si nu le mai recunoaste atunci cand incerc sa apelez la ele).