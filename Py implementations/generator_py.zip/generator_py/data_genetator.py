import random

print("Introduceti numarul de noduri corespunzator: ")    
size = int(input())                                           #introducerea numarului de noduri dorit pentru generarea grafului
adj_matrix = []
i = 0
while i < size:
    j = 0
    while j < size:
        adj_matrix.append(0)
        j = j + 1
    i = i + 1
i = 0
while i < size:
    j = 0
    while j < size:
        if i != j:                                             #elementele simetrice fata de diagonala principala a matricei vor avea valori egale
             adj_matrix[size*i +j] = random.randrange(1,10)    #elementele care au coordonatele pozitiei egale(constituie diagonala principala a matrice) sunt initializate cu 0
             adj_matrix[size*j + i] = adj_matrix[size*i +j]
        j = j + 1
    i = i + 1
i = 0
while i < size:                                                 #afisarea matricei generate
    j = 0
    while j < size:
        print(str(adj_matrix[i*size + j]))
        j = j + 1
    print("\n")
    i = i + 1