#ifndef _PRIM_H_                                       //file guards(asigura faptul ca functiile vor fi incluse o singura data)
#define _PRIM_H_

int minimum_key(int k[], int min_span_tree[],int no_of_nodes2);         //prototipul functiei "minimum_key" definita in fisierul sursa "prim.c"
void prim(int a_graph[][700],int no_of_nodes2);                         //prototipul functiei "prim" regasita in fisierul "prim.c
#endif // _PRIM_H_                                      //file guards
