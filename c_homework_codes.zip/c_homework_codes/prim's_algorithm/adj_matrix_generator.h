#ifndef _GEN_H_                                                 //file guards
#define _GEN_H_

#include<stdlib.h>
#include<stdio.h>

void randomize(int adj_matrix[][700],int no_of_nodes2);           //prototipul functiei de randomizare a matricei descrisa in fisierul sursa

#endif // _GEN_H_                                                //file guards
