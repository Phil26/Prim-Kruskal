#ifndef _KRUSK_H_
#define _KRUSK_H_

#include <stdio.h>
#include <stdlib.h>
//#include "graph.h"
int L[20];

void kruskal(int n, int m, int L[20], struct graph *G);              //prototipul functiei "kruskal" descrisa in fisierul "kruscal.c"

#endif
